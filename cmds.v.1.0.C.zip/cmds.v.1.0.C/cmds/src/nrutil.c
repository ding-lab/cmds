/***************************************************************************
 *   Copyright (C) 2008 by Xiaoqi Shi   *
 *   xshi@linus223   *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/
#include <malloc.h>
#include <stdio.h>
 
void nrerror(error_text)
char error_text[];
{
	void exit();

	fprintf(stderr,"Numerical Recipes run-time error...\n");
	fprintf(stderr,"%s\n",error_text);
	fprintf(stderr,"...now exiting to system...\n");
	exit(1);
}


int *ivector(n)
int n;
{
	int *v;

	v=(int *)calloc((unsigned) (n),sizeof(int));
	if (!v) nrerror("allocation failure in ivector()");
	return v;
}

double *dvector(n)
int n;
{
	double *v;

	v=(double *)calloc((unsigned) (n),sizeof(double));
	if (!v) nrerror("allocation failure in dvector()");
	return v;
}


float *fvector(n)
int n;
{
	float *v;

	v=(float *)calloc((unsigned) (n),sizeof(float));
	if (!v) nrerror("allocation failure in fvector()");
	return v;
}



double **dmatrix(nr,nc)
int nr,nc;
{
	int i;
	double **m;

	m=(double **) calloc((unsigned) (nr),sizeof(double*));
	if (!m) nrerror("allocation failure 1 in dmatrix()");
	
	for(i=0;i<nr;i++) {
		m[i]=(double *) calloc((unsigned) (nc),sizeof(double));
		if (!m[i]) nrerror("allocation failure 2 in dmatrix()");
		
	}
	return m;
}

float **fmatrix(nr,nc)
int nr,nc;
{
	int i;
	float **m;

	m=(float **) calloc((unsigned) (nr),sizeof(float*));
	if (!m) nrerror("allocation failure 1 in fmatrix()");
	
	for(i=0;i<nr;i++) {
		m[i]=(float *) calloc((unsigned) (nc),sizeof(float));
		if (!m[i]) nrerror("allocation failure 2 in fmatrix()");
		
	}
	return m;
}


float **fmatrix_realloc(m,nr,nc)
int nr,nc;
float **m;
{
	int i;

	m=(float **) realloc(m,(unsigned) (nr)*sizeof(float*));
	if (!m) nrerror("allocation failure 1 in dmatrix()");

	for(i=0;i<nr;i++) {
		m[i]=(float *) realloc(m[i], (unsigned) (nc)*sizeof(float));
		if (!m[i]) nrerror("allocation failure 2 in dmatrix()");
	}
	return m;
}

int **imatrix(nr,nc)
int nr,nc;
{
	int i,**m;

	m=(int **)calloc((unsigned) (nr),sizeof(int*));
	if (!m) nrerror("allocation failure 1 in imatrix()");

	for(i=0;i<nr;i++) {
		m[i]=(int *)calloc((unsigned) (nc),sizeof(int));
		if (!m[i]) nrerror("allocation failure 2 in imatrix()");
	}
	return m;
}





void free_ivector(v,n)
int *v,n;
{
	free((char*) (v));
}

void free_dvector(v,n)
double *v;
int n;
{
	free((char*) (v));
}

void free_fvector(v,n)
float *v;
int n;
{
	free((char*) (v));
}

void free_dmatrix(m,nr,nc)
double **m;
int nr,nc;
{
	int i;

	for(i=nr-1;i>=0;i--) free((char*) (m[i]+0));
	free((char*) (m+0));
}

void free_imatrix(m,nr,nc)
int **m;
int nr,nc;
{
	int i;

	for(i=nr-1;i>=0;i--) {
		free((char*) (m[i]+0));
		if(i<5) {
			int a=0;
		}
	}
	free((char*) (m+0));
	 
}





