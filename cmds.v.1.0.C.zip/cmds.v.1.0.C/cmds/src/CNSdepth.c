#include "nrutil.h"
#include "hmm.h"
 
#define	MaxRL	500000  

char *nst_nt16_rev_table = "XACMGRSVTWYHKDBN"; 

int cns_usage()
{
	fprintf(stderr, "\nUsage:   cnv cnsdepth [options] cnsfile outputfile\n\n");
	fprintf(stderr, "Optional Arguments:\n");
	fprintf(stderr, " -y  STRING      assign marker file[defaul=NULL]\n");
	fprintf(stderr, " -q  INT         map quality cutoff[defaul=40]\n");
	fprintf(stderr, " -w  INT         window size[defaul=1000]\n"); 
	fprintf(stderr, " -b  INT         mininum position[defaul=1]\n");
	fprintf(stderr, " -e  DOUBLE      maximus position[defaul=1000000000000]\n");
	fprintf(stderr, " -m  INT         GC window size[defaul=1000]\n");
	fprintf(stderr, " -c  FLOAT       GC cutoff[defaul=0.5]\n\n");
	return 1;
}

int h_DepthCNS(int argc, char *argv[]) {
//char *cns, char *marker, char *outfile) {

	/* default parameters*/
	 
	int	mapQ_cutoff=40;
	int	win=1000;
	int	start=1;
	double	end=1000000000000.0;
	int	mea_win=1000;
	float	GC_cutoff=0.5;
	gzFile	fp_m=0; 

	char c;
	while ((c = getopt(argc, argv, "q:w:b:e:m:c:y:")) >= 0) {
		switch (c) {
		 
		case 'q': mapQ_cutoff=atoi(optarg);break;
		case 'w': win=atoi(optarg);break;
		case 'b': start=atoi(optarg);break;
		case 'e': sscanf(optarg,"%d",&end);break;
		case 'm': mea_win=atoi(optarg);break;
		case 'c': GC_cutoff=atof(optarg);break;
		case 'y': fp_m = gzopen(optarg, "r");assert(fp_m);break;
		default:
			cns_usage();
			exit(1);
		}
	}
	if (argc - optind < 2) {
		cns_usage();
		exit(1);
	}
	FILE	*fpout= fopen(argv[optind+1], "w");
	assert(fpout);
	
	fprintf (stdout,"\ngenerating depth file\n"); 
	int a=0;
	DepthCNS(mapQ_cutoff, win, start, end, mea_win, GC_cutoff, fp_m, argv[optind], fpout, 0, &a);
	fclose(fpout);
	fprintf (stdout,"finished\n"); 
	return 1;
}

float **DepthRead(FILE *fp,int *count) {
	 
	 
	int	size = MaxRL;
	float **data = fmatrix(3,size);
	float chr,pos,nratio,zscore,logp;
	while(!feof(fp)) {
		
		//if(fscanf(fp, "%f %f %f %f\n", &pos,&depth,&hetrate,&GC) != 4) {
		if(fscanf(fp, "%f %f %f %f %f\n", &chr,&pos,&nratio,&zscore,&logp) != 5) {
			fprintf(stderr," reading file terminate at line %d\n",*count);
			break;
		}
		if(*count >= size) {
			size += MaxRL;
			data = fmatrix_realloc(data, 3, size);
		} 
		data[0][*count]=pos;
		data[1][*count]=nratio;
		data[2][*count]=zscore;
		*count=*count+1;
	}
	data = fmatrix_realloc(data, 3, *count);  
	return data;
}
void ReadCNSLine(FILE *fpout, gzFile fp, int *len, int *i, char **name, unsigned *low, unsigned *high)
 
{	 
	if(*i>=*len)  {
		gzread(fp, len, sizeof(int));
		if(*name!=NULL||*name!=0) {
			free(*name);
		}
		*name = (char*)malloc(*len);
		gzread(fp, *name, *len);
		gzread(fp, len, sizeof(int));
		*i=0; 
	}
	 
	gzread(fp, low, sizeof(unsigned));
	gzread(fp, high, sizeof(unsigned));
	// chr, pos, refB, cnsB, cnsQ, depth, avg01, mapQmax		
	/*fprintf(fpout, "%s\t%d\t%c\t%c\t%d\t%d\t%.2f\t%d\t%d", *name, (*i + 1), nst_nt16_rev_table[high>>28],
						nst_nt16_rev_table[high>>24&0xf], high>>16&0xff, low&0xff, (float)(low>>20&0xfff)/16.0,
						low>>8&0x3f, (low>>15&0x1f)<<1);
	*/
	*i=*i+1;
} 

int ResidueIndex(char sym)
{
	char *s;
	sym = toupper((int) sym);
	if ((s = strchr(nst_nt16_rev_table, (int) sym)) != NULL) return (s-nst_nt16_rev_table);
	fprintf(stderr, "bad char!");
	exit(1);
}

 

float **DepthCNS (int mapQ_cutoff,int  win,int  start,double end,int  mea_win,float GC_cutoff, gzFile fp_m, char *cns, FILE *fpout, int flag,int *count) {
	
	gzFile fp = gzopen(cns, "r");
	assert(fp);

	int	i;
	int	pos=0;
	int	pos_m=0;
	int	len=0;
	int	len_m=0;
	char	*chr=0;
	char	*chr_m=0;
	unsigned	low, high;
	unsigned	low_m, high_m;
	int	basecount[strlen(nst_nt16_rev_table)];
	for( i=0; i<strlen(nst_nt16_rev_table); i++)	basecount[i]=0;	//initialize to zero

	int	hetcount=0;
	 
	char	refbases[mea_win+1];
	char	cnsbases[mea_win+1];
	int	i_win = 0;
	float	avg[4] = {0.0, 0.0, 0.0, 0.0};
	int	avg_count = 0;

	int	size = MaxRL;
	float	**data=0;
	if(flag==1) data=fmatrix(3,size);
	 
	
	while(! gzeof(fp)) {
		 
		ReadCNSLine(stdout, fp, &len, &pos, &chr, &low, &high);		/*read the cns file*/
		char refbase = nst_nt16_rev_table[high>>28];		/* get position base and depth score */
		char cnsbase = nst_nt16_rev_table[high>>24&0xf];
		int depth = low&0xff;
		int depth_m;
		int max_mapQ_m;

		if(fp_m) {
			ReadCNSLine(stdout, fp_m, &len_m, &pos_m, &chr_m, &low_m, &high_m);	/*read the marker file*/
			if(pos!=pos_m ||  strcmp(chr,chr_m)!=0) {
				fprintf(stderr, "warning, Marker and input files doesn't match\n");
				exit(1);
			}
		/* get position base and depth score */
		
			depth_m = low_m&0xff;
			max_mapQ_m = low_m>>8&0x3f;
		}

		refbases[i_win] = refbase;
		cnsbases[i_win] = cnsbase;

		basecount[ResidueIndex(refbase)]++;	/*initialized as 0!*/	
		 
		if(cnsbase != 'A' && cnsbase != 'C' && cnsbase != 'G' && cnsbase != 'T' && cnsbase != 'N' )	hetcount++;		
		

		if(i_win==mea_win){
			refbase=refbases[0];
			cnsbase=cnsbases[0];
			
			for( i = 0; i <= mea_win-1; i++)	refbases[i] = refbases[i+1];
			for( i = 0; i <= mea_win-1; i++)	cnsbases[i] = cnsbases[i+1];
			
			i_win--;
			basecount[ResidueIndex(refbase)]--;
			if(cnsbase != 'A' && cnsbase != 'C' && cnsbase != 'G' && cnsbase != 'T' && cnsbase != 'N') hetcount--;		 
		}
		i_win++;
		 
		if(fp_m && mapQ_cutoff > 0 && (depth_m != 1 || max_mapQ_m < mapQ_cutoff)) 
		continue;	 //skip unreliable positions
		
		 
		if(pos >= start && pos <= end) {
			avg[0] += pos;
			avg[1] += depth;
			float GC;
			int nbases = basecount[ResidueIndex('A')]+basecount[ResidueIndex('C')]+basecount[ResidueIndex('G')]+basecount[ResidueIndex('T')];
			GC = nbases>100 ? (float) (basecount[ResidueIndex('C')]+basecount[ResidueIndex('G')])/nbases: 0.5;
			avg[2] += (float) hetcount/mea_win;
			avg[3] += GC;
			avg_count++;
		}
		else if(pos>end) break;

		if(avg_count >= win){
			for(i = 0; i<=3; i++) avg[i] /= win;		//assigning to a data_matrix
			if(fpout) {
				fprintf (fpout,"%d\t%.2f\t%.6f\t%.6f\n",(int) avg[0],avg[1],avg[2],avg[3]);
				fflush(fpout);
			}
			if (flag==1) {
				if(*count >= size) {
					size += MaxRL;
					data = fmatrix_realloc(data, 3, size);	
				}
				data[0][*count]=avg[0];
				data[1][*count]=avg[1];
				data[2][*count]=avg[3];
				*count=*count+1;
			}
			 
			avg_count=0;
			for(i = 0; i<=3; i++) avg[i] = 0.0;	
		}
	}
	if(flag==1)  data = fmatrix_realloc(data, 3,*count); 
	if(fp_m) gzclose(fp_m);
	gzclose(fp);
	return data;
} 
