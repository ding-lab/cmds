#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <unistd.h>
#include <assert.h>
#include <zlib.h>


#ifndef LZERO
#define	LZERO  -10000000000.0
#define f_TransProb  0.000001
#define MAX(x,y)        ((x) > (y) ? (x) : (y))
#define MIN(x,y)        ((x) < (y) ? (x) : (y))

typedef struct {
	int N;		/* number of states; */
	int M; 		/* number of observation */
	float	**data;
	double	*tran;	/*  transition parameter */
	double	**A;	/*  transition prob */
	double	**Er;	/*  emission probability of copy number ratio*/
	double	**Ez;	/*  emission probability of allele z score*/
	 
	//double	*slopes;	/*  initial state distribution. */
	//double	*intercepts;	/*  initial state distribution. */

	double **mean;
	double **var;
	
} HMM;
 
 
#ifdef __cplusplus
extern "C" {
#endif
int h_CMDS(int argc, char *argv[]) ;   
int h_HMM(int argc, char *argv[]);
int h_DepthCNS(int argc, char *argv[]) ; 
float **DepthRead(FILE *fp,int *count);
float **DepthCNS(int mapQ_cutoff,int  win,int  start,double end,int  mea_win,float GC_cutoff, gzFile fp_m, char *cns, FILE *fpout, int flag,int *count);
 
#ifdef __cplusplus
}
#endif
 
#endif
