//Copyright 2009 Qunyuan Zhang

//This file is part of CMDS.

//CMDS is free software: you can redistribute it and/or modify
//it under the terms of the GNU General Public License as published by
//the Free Software Foundation, either version 3 of the License, or
//(at your option) any later version.

//CMDS is distributed in the hope that it will be useful,
//but WITHOUT ANY WARRANTY; without even the implied warranty of
//MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//GNU General Public License for more details.

//You should have received a copy of the GNU General Public License
//along with this program.  If not, see <http://www.gnu.org/licenses/>.

#include "hmm.h"
#include "statis.hh"
#include "nrutil.h"
#define	MaxC	10000    
#define PLen	30

int cmds_usage()
{
	fprintf(stderr, "\nUsage:   cnv cmds [options]  [infile] [outfile]\n\n");
	fprintf(stderr, "Optional Arguments:\n"); 
	fprintf(stderr, " -h  indicates that infile contains one line of header\n"); 
	fprintf(stderr, " -w  INT             block size [default=50]\n"); 
	fprintf(stderr, " -s  INT             step size [default=1]\n"); 
	fprintf(stderr, " -c  float           outlier cutoff value [default=10.0]\n"); 	
	fprintf(stderr, " -m  STRING          missing value represented in infile[default=-999]\n"); 
	return 1;
}

int cmds_update(char *file,FILE *fpout,double zSum,double z2Sum, int zN){
	double zSD=(z2Sum- zSum*zSum/zN)/(zN-1.0);
	zSD =  sqrt(zSD);
	double zMean=zSum/zN; 
	float z;
	FILE *fptmp = fopen(file, "r");
	assert(fptmp);
	char str[PLen];
	//char **p;
	while(!feof(fptmp)) {
		int i;
 		for(i=0;i<5;i++) {	 
 			fscanf(fptmp,"%s",str);
 			fprintf(fpout,"%s\t",str);
 		}
		fscanf(fptmp,"%f\n",&z);
		double sdi=(z-zMean)/zSD;
		double pi= alnorm(sdi,1);
		if(isnan(sdi)) pi=sdi;
		fprintf(fpout,"%f\t%f\t%f\n",z,sdi,pi);
	}
	close(fptmp);
	
}


int cmds_test(float cutoff, FILE *fptmp, char *chr,char pos[][PLen], float **data, int win,int size, int missing, int *zN, double *zSum, double *z2Sum){
	
	int i, j, k;
	double sum_x,sum_x2,sum_y,sum_y2,sum_xy,z;
	double mean_xy=0.0;
	double mean_z=0.0;
	int number=0;
	int n_z=0;
 	//caculate mean xy
	
	for(i=0;i<win;i++) {
		for(j=1;j<size;j++){ 
			if(data[i][j] == missing) continue;
			if (data[i][j]>cutoff) data[i][j]=cutoff; 
 // the line above is added by Qunyuan Zhang, for setting extreme high copy number (outlier) down to a cutoff;
			mean_xy +=  data[i][j]; 
			number++;
			//fprintf (stdout,"%f\t", data[i][j]); 
		}
	}
	mean_xy /= number;

	for(i=0;i<win-1;i++) {
		for(j=i+1;j<win;j++){ 
			sum_x=0.0;
			sum_x2=0.0;
			sum_y=0.0;
			sum_y2=0.0;
			sum_xy=0.0;
			z=0.0;
			number=0;
			for(k=0;k<size;k++) {
				if(data[i][k]==missing || data[j][k]==missing)
				continue;
				 
				sum_x+=data[i][k];
				sum_x2+=pow(data[i][k],2);
				sum_y+=data[j][k];
				sum_y2+=pow(data[j][k],2);
				sum_xy+=data[i][k]*data[j][k];
				number++;
				 
			}
			z=(number*sum_xy-sum_x*sum_y)/(sqrt(number*sum_x2 - pow(sum_x,2)) * sqrt(number*sum_y2-pow(sum_y,2))); 
			z= (1.0/2*log((1.0+z) / (1.0-z))) * sqrt(number-3);
			if(isnan(z)) continue;
			// deleted by Qunyuan Zhang, cutoff should not be used here:  if(isinf(z) || z>=cutoff) z=10.0;
			mean_z += z;
			n_z++;
	
		}
	}
	mean_z = mean_z /n_z;
 	//fprintf (stdout,"%s\t%s\t%s\t%s\t%f\t%f\t%lf\t%lf\n", chr,pos[0],pos[win-1],pos[win/2],mean_xy,mean_z,*zSum,*z2Sum);
	fprintf (fptmp,"%s\t%s\t%s\t%s\t%f\t%f\n", chr,pos[0],pos[win-1],pos[win/2],mean_xy,mean_z);
	if(mean_z==0||n_z==0||isnan(mean_z)) return 1;
	*zSum = *zSum + mean_z;
	*z2Sum = *z2Sum + pow(mean_z,2);
	*zN = *zN+1;
	
	return 1;
}

int h_CMDS(int argc, char *argv[]) {
 
	// default parameters
	int	win=50;
	float	cutoff=10.0;
	int	step=1;
	int	missing = -999;
	int	i=0;
	int	j=-2;
	int	size = MaxC;
	char	chr[3]="";
	char	c;
	int	header=0;
	 
	while((c = getopt(argc, argv, "hw:s:c:m:")) >= 0) {
		switch (c) {
		case 'h': header=1;break;
		case 'w': win=atoi(optarg);break;
		case 'c': cutoff=atof(optarg);break;
		case 's': step=atoi(optarg);break;
		case 'm': missing=atoi(optarg);break; 
		default:
			cmds_usage();
			exit(1);
		}
	} 
	if (argc - optind < 2) {
		cmds_usage();
		exit(1);
	}

	FILE	*fp = fopen(argv[optind], "r");
	assert(fp);
	FILE	*fptmp=0;
	FILE	*fpout = fopen(argv[optind+1], "w");
	assert(fpout);
	strcat(argv[optind+1],".tmp");
	fprintf (stdout,"\nrunning cnv cmds analysis\n");
	
	char line [ 9999 ]; /* or other suitable maximum line size */
	int n;
	char *l=0;
	int zN;
	double zSum,z2Sum;
	double par2=0.0;
	double par3=0.0;
	char chr_str[3]="";
	char str[PLen];
	char pos[win][PLen];
 
	//read first line and caculate sample size from file
	 
	l=fgets ( line, sizeof line, fp )  ; /* read a line */
/*
	char *pch;
	pch = strtok (line,"\t");
	while (pch != NULL)
	{
		printf ("%s\n",pch);
	 	pch = strtok (NULL, "\t");
		j++;
	}
*/
	while(sscanf(l, "%s%n", str, &n ) == 1 ) {
		l += n;	
		j++;
	}
 
	size=j;
	float	**data = fmatrix(win,size);
	 
	while(!feof(fp)) {
		//l=fgets ( line, sizeof line, fp );
	/*	pch = strtok (line,"\t");
		sscanf(pch,"%s",chr_str);
		if( strcmp(chr,chr_str)!=0  ){
			if(i>0 && i!=win-step) cmds_test(chr,data,i,size,missing,&par1,&par2,&par3);
			strcpy(chr,chr_str);
			fprintf (stdout,"chromosome:%s\n", chr);
			i=0;
			//sscanf(optarg,"%d",&end);
		}
*/
		fscanf(fp, "%s", chr_str);
		if( strcmp(chr,chr_str)!=0  ){
			if(i>0 && i!=win-step) {
				 cmds_test(cutoff,fptmp,chr,pos,data,i,size,missing,&zN,&zSum,&z2Sum);
				fclose(fptmp);
				cmds_update(argv[optind+1],fpout,zSum,z2Sum,zN);
				
			}
			strcpy(chr,chr_str);
			zSum=0.0;
			z2Sum=0.0;
			zN=0;
			fptmp = fopen(argv[optind+1], "w");
			assert(fptmp);
	
fprintf(fpout, "chromosome\t start\t end\t middle\t mean_CN\t z_score\t SD\t p-value\n");	

			i=0;
		}
		
		fscanf(fp, "%s", &pos[i][0]);
		for(j=0;j<size-1;j++){	 
			//pch = strtok (NULL, "\t");
			//data[i][j]=atof(pch);
			fscanf(fp, "%f", &data[i][j]);
		}
		fscanf(fp, "%f\n", &data[i][j]);
		i++;
		//block size reach, do test
		if(i==win) {
			int test=1;
			cmds_test(cutoff,fptmp,chr,pos,data,win,size,missing,&zN,&zSum,&z2Sum);
			//shift data block by step 
			int k;
			for(k=0;k<win-step;k++){
				int l;
				strcpy(pos[k],pos[k+step]);
				for(l=0;l<size;l++){
					data[k][l]=data[k+step][l];
				}
			}
			i=k;
		}
	
	}
	if(i>0 && i!=win-step)
	cmds_test(cutoff,fptmp,chr,pos,data,i-1,size,missing,&zN,&zSum,&z2Sum);
	fclose(fptmp);
	cmds_update(argv[optind+1], fpout,zSum,z2Sum,zN); 
	fprintf (stdout,"finished\n"); 
	 
	fclose(fp);
	fclose(fpout);
	if(remove(argv[optind+1])) fprintf(stdout,"Remove file%s Error",argv[optind+1]);
	return 1;
}
