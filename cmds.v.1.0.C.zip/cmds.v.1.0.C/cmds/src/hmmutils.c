/***************************************************************************
 *   Copyright (C) 2008 by Xiaoqi Shi   *
 *   xshi@linus223   *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#include "nrutil.h"
#include "hmm.h" 
#define PI	3.1415926536	
#define SIGNIFICANT 5

int hmm_usage()
{
	fprintf(stderr, "\nUsage:   cnv hmm [options]  [cnsfile] [infile]\n\n");
	fprintf(stderr, "Optional Arguments:\n");
	fprintf(stderr, " -i                 if present program will use file created from cnsdepth as input[infile], otherwise take marker[markerfile] and cns[cnsfile] file as inputs\n\n");

	fprintf(stderr, "parameters for depth&GC data preparation:\n");
	fprintf(stderr, " -y  STRING          assign marker file[defaul=NULL]\n");
	fprintf(stderr, " -d  STRING          create and write out depth file from marker and cns file \n");
	fprintf(stderr, " -o  STRING          results file(states and region information)\n");
	fprintf(stderr, " -q  INT             map quality cutoff[defaul=40]\n");
	fprintf(stderr, " -w  INT             window size[defaul=1000]\n"); 
	fprintf(stderr, " -b  INT             mininum position[defaul=1]\n");
        fprintf(stderr, " -e  DOUBLE          maximus position[defaul=999999999]\n");
	fprintf(stderr, " -m  INT             GC window size[defaul=1000]\n");
	fprintf(stderr, " -c  FLOAT           GC cutoff[defaul=0.5]\n\n");

	fprintf(stderr, "parameters for HMM process:\n");
	fprintf(stderr, " -a  STRING          HMM algorithm [defaul='viterbi']\n"); 
	fprintf(stderr, " -n  INT             max copy number[defaul=3]\n"); 
	fprintf(stderr, " -f  INT             median filter size[defaul=3]\n"); 
	fprintf(stderr, " -g  INT             GC correction 1:apply 0:not apply[defaul=1]\n"); 
	fprintf(stderr, " -t  INT             transition probability 1:update 0:not update[defaul=0]\n"); 
	fprintf(stderr, " -r  DOUBLE          cnv rate[defaul=0.001]\n"); 
	fprintf(stderr, " -s  DOUBLE          nv size[defaul=0.1]\n");
	fprintf(stderr, " -k  INT             minimum number of markers[defaul=5]\n"); 
        fprintf(stderr, " -x  INT             The maximum # of bases a cnv can extend without evidence[defaul=450000]\n"); 
	//fprintf(stderr, " -p  INT             Log Pvalue cut off[defaul=2]\n\n"); 
        fprintf(stderr, " -l  DOUBLE          Log Likelihood Ratio Cut off[defaul=10]\n"); 
	return 1;
}

/*double LogGaussianPDF(double x, double m, double v);*/
double LogGaussianPDF(double x, double m, double v)
{
	double a;
	return -1.0/2*log(2*PI*v)-pow(x-m,2)/(2*v);
} 

 double StatMean(int n, float *data){
	double sum = 0.0;
	int	i;
	for(i=0;i<n;i++){
		sum += data[i];
	}
	sum /= n;
	return sum;
}


double StatVar(int n, double mean, float *data){
	double sum = 0.0;
	int	i;
	for(i=0;i<n;i++){
		sum += pow(data[i] - mean, 2);
	}
	sum /= (n-1);
	return sum; 

}

void UpdateEmissHMM(HMM *hmm) {

    int i, j, k;
	
    for (j = 0; j < hmm->N; j++) { 
	for (i = 0; i < hmm->M; i++) {
            	hmm->Er[j][i] = LogGaussianPDF(hmm->data[1][i],hmm->mean[j][0],hmm->var[j][0]); 
		hmm->Ez[j][i] = LogGaussianPDF(hmm->data[2][i],hmm->mean[j][1],hmm->var[j][1]); 
	}
    }
}
  

void  InitHMM(HMM *hmm, int medianFilterSize,int M, int N, double cnvRate, double cnvSize)
{
	hmm->N=N;
	hmm->M=M;
	int	len_y = 0;
	double	mean[2]= {0.0, 0.0};
	int	idx_median =  (medianFilterSize - 1) / 2;
	int	i_buffer, i, k;
	float	buffer_sort[medianFilterSize];
	float	buffer[medianFilterSize];

	for(i_buffer = 0; i_buffer < idx_median; i_buffer++)	buffer[i_buffer]=0.0;
	 
	for(i=0; i<hmm->M;i++) {
		//could be simplified further!
		buffer[i_buffer] = hmm->data[1][i]; 
		if(i_buffer == medianFilterSize - 1) {
			int j,k;
			memmove(buffer_sort, buffer, (medianFilterSize)*sizeof(float));
			for (j =medianFilterSize -1; j >=1; j--) {
				for (k = 1; k <= j; k++) {
					if(buffer_sort[k-1] > buffer_sort[k]) {
						float temp = buffer_sort[k];
						buffer_sort[k] = buffer_sort[k-1];
						buffer_sort[k-1] = temp;
					}
				}
			}
			hmm->data[1][len_y] = buffer_sort[idx_median];
			len_y++;
			for (j = 0; j <= medianFilterSize -2; j++) {
				buffer[j] = buffer[j+1];
			}
			i_buffer--;
		}
		i_buffer++;
	}
	
	/* caculate mean */
	for(k=0; k<=1; k++)
		mean[k] = StatMean(hmm->M,&hmm->data[k+1][0]);
	
	/* inital HMM */
 	hmm->mean = (double **) dmatrix(hmm->N, 2); 
	hmm->var = (double **) dmatrix(hmm->N, 2);
	//hmm->A = (double **) dmatrix( hmm->N, hmm->N);
	hmm->Er = (double **) dmatrix(hmm->N, hmm->M);
	hmm->Ez = (double **) dmatrix(hmm->N, hmm->M);
	hmm->tran = (double *) dvector(hmm->N);

	 
	for (i = 0; i < hmm->N; i++) {
		k = i-2;
		if(i >= 3) k--;
		hmm->mean[i][0] = k;
		if( (i%2) ==0) {
			hmm->mean[i][1] = mean[1] - fabs(mean[1])/2.0;
		}
		else {
			hmm->mean[i][1] =  mean[1] + fabs(mean[1])/2.0;
		}
		
		for(k=0; k<=1; k++) {
			hmm->var[i][k] = StatVar(hmm->M,hmm->mean[i][k],&hmm->data[k+1][0]) ;
		}
		hmm->tran[i] = (i == 2)?cnvRate:cnvSize; 
	}

	UpdateEmissHMM(hmm);
}


void UpdateTranHMM(HMM *hmm)
{
	int i, j, k;
 
	for (i = 0; i < hmm->N; i++) {
		double state= hmm->tran[i]; 
		 
		for (j = 0; j < hmm->N; j++) {
			if(i == j) hmm->A[i][j] = 1.0 -state;
			else hmm->A[i][j] =  state/(hmm->N-1) ; 
			hmm->A[i][j] = log(hmm->A[i][j]); 
		}
	}
 
}

void FreeHMM(HMM *hmm)
{
	//free_dmatrix(hmm->A, hmm->N, hmm->N);
	free_dmatrix(hmm->Er, hmm->N, hmm->M);
	free_dmatrix(hmm->Ez, hmm->N, hmm->M);
	free_dvector(hmm->tran, hmm->N);
	free_dmatrix(hmm->data,3, hmm->M);
	free_dmatrix(hmm->mean, hmm->N, 2);
	free_dmatrix(hmm->var, hmm->N, 2);
} 

double StatTProb( int n, double x) {
	if(n<=0 || (abs(n) - abs((int)n)!=0) ) {
		fprintf(stderr, "Invalid n: %d\n\n",n); 
		exit(1);
	}
	double w=atan2(x/sqrt(n), 1);
	double z= pow(cos(w),2);
	double y=1.0;
	int i;
	double a,b;
	for (i = n-2; i>=2;i-=2) {
		y = 1.0+ (i-1.0)/i*z*y;
	}
	if(n%2==0) {
		a = sin(w)/2;
		b = 0.5;
	}
	else {
		a= (n==1)? 0:sin(w)*cos(w)/PI;
		b= 0.5 + w/PI;
	}
	double t=MAX(0, 1-b-a*y);
	if(t) {
		//int num = abs((int)(log10(abs(t)) - SIGNIFICANT)); 
		//int size=(int)log10(num)+2;
		//char num_str[size];
		//sprintf(num_str, "%d", num);
		//char f[size+3];
		//char a1[]="%.";
		//strcat(a1,num_str);
		//sprintf(f,"%s", strcat(a1,"f"));
		//char str[(int)log10(abs(t))+num+2+1];
		//sprintf(str, f, t); 
   
		return t;
	}
	else return 0;
}

void LogLikelihoodRatio(HMM *hmm, int i_start,int i_end, int CN, double* log10Ratio,double* CNest){

    //my ($self,$data,$i_start,$i_end,$CN)=@_;
    double logProbNeutral=0;
    double logProbCNV=0;
    double logprob;
    int t;
    double avgdepth=0;
    for(t=i_start;t<=i_end;t++){
        //copy number neutral model
        logprob=LogGaussianPDF(hmm->data[1][t],hmm->mean[2][0],hmm->var[2][0]) + LogGaussianPDF(hmm->data[2][t],hmm->mean[2][1],hmm->var[2][1]);
        logProbNeutral+=logprob;

        //copy number model
        logprob=LogGaussianPDF(hmm->data[1][t],hmm->mean[CN][0],hmm->var[CN][0]) + LogGaussianPDF(hmm->data[2][t],hmm->mean[CN][1],hmm->var[CN][1]);
        logProbCNV+=logprob;
        avgdepth+=hmm->data[1][t];
    }
    avgdepth/=(i_end-i_start+1);
    *CNest=avgdepth;
    *log10Ratio=(logProbCNV-logProbNeutral)/log(10);

}

double WelchTtest(double *glob_stat, float *stat_data, int stat_count) {
	
// 	int n1= 21;
 	int n1= (int) stat_count;
	int n2= (int) glob_stat[0];
 	double m1 = StatMean(n1,stat_data);
// 	double m1 = 16.53619047;
	double m2 = glob_stat[1];

 	double v1 = StatVar(n1,m1,stat_data);
// 	double v1 = 25.0572547619047;
	double v2 = glob_stat[2];
	double Pvalue = 0.0;

	if(v1>0||v2>0){
		double diffmean=m1-m2;
		double tstat=diffmean/sqrt(v1/n1+v2/n2);
		double df=pow(v1/n1+v2/n2,2)/(pow(v1,2)/(pow(n1,2)*(n1-1))+(pow(v2,2)/(pow(n2,2)*(n2-1))));
		double tprob=StatTProb((int)df+1, tstat);
		Pvalue=(tstat>0)?tprob:(1-tprob);
	}
	else Pvalue=1.0;
	return Pvalue>1e-20? -log10(Pvalue):20 ;
}

int h_HMM(int argc, char *argv[]) {
 
	// default parameters
	
	int	mapQ_cutoff=40;
	int	win=1000;
	int	start=1;
	long	end=999999999;
	int	mea_win=1000;
	float	GC_cutoff=0.5;

	HMM  	hmm;
	int	maxCN = 3; 
	int	medianFilterSize =3;
	int	minNumMarker = 5;
	float	cnvRate=0.001;
	float	cnvSize=0.1;
	int	GCcorrection = 1;
	char	*method = "viterbi";
	int	TPupdate=0;
        int	maxExtInterval = 450000;
	//int	NLogPvalueCutoff = 2;
        double  LLRcutoff=10.0;
	int	flagi=0;
	FILE	*fp=0;
	FILE	*fp_state=0; 
	gzFile	fp_m=0; 
	int c;	 
	
	while((c = getopt(argc, argv, "id:o:q:w:b:e:m:c:a:n:f:g:t:r:s:k:x:l:y:")) >= 0) {
		switch (c) {
		case 'i': flagi=1;break;
		case 'o': fp_state= fopen(optarg, "w");assert(fp_state);break; 
		case 'd': fp= fopen(optarg, "w");assert(fp);break; 
		case 'q': mapQ_cutoff=atoi(optarg);break;
		case 'w': win=atoi(optarg);break;
		case 'b': start=atoi(optarg);break;
		case 'e': sscanf(optarg,"%d",&end);break;
		case 'm': mea_win=atoi(optarg);break;
		case 'c': GC_cutoff=atof(optarg);break;
		case 'a': method=optarg;break; 
		case 'n': maxCN=atoi(optarg);break;
		case 'f': medianFilterSize=atoi(optarg);break;
		case 'g': GCcorrection=atoi(optarg);break;
		case 't': TPupdate=atoi(optarg);break;
		case 'r': cnvRate=atof(optarg);break;
		case 's': cnvSize=atof(optarg);break;
		case 'k': minNumMarker=atoi(optarg);break;
		case 'x': maxExtInterval=atoi(optarg);break;
		case 'y': fp_m = gzopen(optarg, "r");assert(fp_m);break;
		//case 'p': NLogPvalueCutoff=atoi(optarg);break;
                case 'l': LLRcutoff=atof(optarg);break;
		default:
			hmm_usage();
			exit(1);
		}
	} 

	int count=0;
	if (flagi==0)
		if(argc - optind < 1) {
			hmm_usage();
			exit(1);
		}
		else {
			fprintf (stdout,"\nread in marker and cns file\n");
			hmm.data=DepthCNS(mapQ_cutoff, win, start, end, mea_win, GC_cutoff, fp_m, argv[optind], fp, 1, &count); 
			if(fp) fclose(fp);
		}
	
	else 
		if(argc - optind < 1) {
			hmm_usage();
			exit(1);
		}
		else{
			fp = fopen(argv[optind], "r");
			assert(fp);
			fprintf (stdout,"\nread in depth file\n");
			hmm.data=DepthRead(fp,&count);
			fclose(fp);
		}
	fprintf (stdout,"Begin HMM:%s GCcorrection:%d TPupdate:%d\n",method,GCcorrection,TPupdate);
	InitHMM(&hmm, medianFilterSize,count, maxCN+1, cnvRate, cnvSize); 
	fprintf (stdout,"%d\t%f\t%f\t%f\t%f\n", hmm.M, hmm.mean[0][0], hmm.var[0][0], hmm.mean[0][1], hmm.var[0][1]);
	fprintf (stdout,"%d\t%f\t%f\t%f\t%f\n", hmm.M, hmm.mean[1][0], hmm.var[1][0], hmm.mean[1][1], hmm.var[1][1]);
	fprintf (stdout,"%d\t%f\t%f\t%f\t%f\n", hmm.M, hmm.mean[2][0], hmm.var[2][0], hmm.mean[2][1], hmm.var[2][1]);
	fprintf (stdout,"%d\t%f\t%f\t%f\t%f\n", hmm.M, hmm.mean[3][0], hmm.var[3][0], hmm.mean[3][1], hmm.var[3][1]);
	//double	glob_stat[3]={hmm.M,hmm.mean*2,hmm.var};
 
	//Define these outside subfun to avoid mutiple time of memeory allocation -- but might not be very helpful at speed? */
	int	*state = ivector(hmm.M);
	double **alpha = dmatrix(hmm.M+1, hmm.N);
	double **beta = dmatrix(hmm.M+1, hmm.N); 

	int	iter = 1;
	double	LScore = LZERO;
	double	Diff;
	do { 
		double PLScore=LScore;;
		 
		if(strcmp(method,"viterbi") ==0 ) {
			Viterbi(&hmm, state, &LScore, TPupdate);
			ViterbiUpdate(&hmm, state, TPupdate);
		} 
		else {
			ForwardBackward(&hmm, alpha, beta, &LScore,TPupdate);
			ForwardBackwardUpdate(&hmm, alpha, beta,TPupdate);
		}
		Diff = LScore - PLScore;
		fprintf(stdout, "%d:%s  log prob = %lf %lf %lf %lf %lf %lf\n", iter, method, LScore, Diff, hmm.mean[2][0], hmm.var[2][0], hmm.mean[2][1], hmm.var[2][1]);
		iter++;
	} while( fabs(Diff) > 0.0001 && iter < 20);

	if(strcmp(method,"viterbi") !=0 ) {
		Viterbi(&hmm, state, &LScore,TPupdate); 
	}

	//print out state information
	if(!fp_state){fp_state=stdout;}
	int i;
	float *stat_data = fvector(hmm.M); 
	int stat_count=0;
	int CNVs_count=0;
	int extend=0;
	int interval=0;
	//double NLog10Pvalue;
	int CNVstart,CNVend,CNVlevel;
        double llr,cn_est;
        int i_start,i_end;
	for(i=0;i<hmm.M;i++){ 
		if(i>0) interval=hmm.data[0][i]-hmm.data[0][i-1];
		if(extend==0 && state[i]!=2){
			CNVstart=hmm.data[0][i];
                        i_start=i;
			CNVlevel=state[i];
			extend=1;
		
			stat_data[stat_count]= hmm.data[1][i];
			stat_count++;
		}
		else if(extend==1 && state[i]!=CNVlevel){
			if(stat_count>=minNumMarker){
				//NLog10Pvalue = WelchTtest(glob_stat,stat_data,stat_count);
				//if( NLog10Pvalue >= NLogPvalueCutoff) {
                            LogLikelihoodRatio(&hmm,i_start,i_end,CNVlevel,&llr,&cn_est);
                                if(llr>LLRcutoff){
					//fprintf(fp_state, "%d\t%d\t%d\t%d\t%d\t%f\n",CNVstart,CNVend,(CNVend-CNVstart),stat_count,CNVlevel,NLog10Pvalue); 
                                        fprintf(fp_state, "%d\t%d\t%d\t%d\t%d\t%f\t%f\n",CNVstart,CNVend,(CNVend-CNVstart),stat_count,CNVlevel,cn_est,llr); 
					CNVs_count++;
				}
			}
			extend=0;
			stat_count=0;
		}
		else if(extend==1 && interval>maxExtInterval){
			if(stat_count>=minNumMarker){
				//NLog10Pvalue = WelchTtest(glob_stat,stat_data,stat_count);
				//if( NLog10Pvalue >= NLogPvalueCutoff) {
					//fprintf(fp_state, "%d\t%d\t%d\t%d\t%d\t%f\n",CNVstart,CNVend,(CNVend-CNVstart),stat_count,CNVlevel,NLog10Pvalue);
                            LogLikelihoodRatio(&hmm,i_start,i_end,CNVlevel,&llr,&cn_est);
                                if(llr > LLRcutoff) {
                                    fprintf(fp_state, "%d\t%d\t%d\t%d\t%d\t%f\t%f\n",CNVstart,CNVend,(CNVend-CNVstart),stat_count,CNVlevel,cn_est,llr); 
					CNVs_count++;	
				}
			}
			stat_count=0;
        		CNVstart=hmm.data[0][i];
                        i_start=i;
	   	        CNVlevel=state[i];
			stat_data[stat_count]= hmm.data[1][i];
			stat_count++;
		}
		else if(extend==1){
			stat_data[stat_count]= hmm.data[1][i];
			CNVend=hmm.data[0][i];
                        i_end=i;
		        stat_count++;
		}
	}
	free_fvector(stat_data, hmm.M);
	fprintf(fp_state, "%d CNV predicted\n",CNVs_count); 
	fclose(fp_state);

	//free up memory
	free_ivector(state,  hmm.M);
	free_dmatrix(alpha,  hmm.M+1, hmm.N);
	free_dmatrix(beta, hmm.M+1,  hmm.N);
	FreeHMM(&hmm);	
 
}
 
