/***************************************************************************
 *   Copyright (C) 2008 by Xiaoqi Shi   *
 *   xshi@linus223   *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#include "hmm.h"
#include "nrutil.h" 

double LAdd (double x, double y ) {
	 
	double	temp, diff, z;
	if (x<y) {
		temp = x;
		x = y;
		y = temp;
	}
	diff = y-x;
	if (diff < -log(-LZERO)){
		return  (x < (LZERO/2))? LZERO: x;
	}
	else {
		z = exp(diff);
	return x+log(1.0+z);
	}
	return z;
}

void ForwardBackward(HMM *hmm, double **alpha, double **beta, double *pprob, int TPupdate)
{
        int     i, j, k;   
	double    sumlogprob, logprob;
         
        for (i = 0; i <= hmm->N-1; i++)
                alpha[0][i] =log(1.0 / hmm->N);
	
	/* forward */
        for (i = 1; i <= hmm->M; i++) {
		float dist = (i < hmm->M)? ((hmm->data[0][i]- hmm->data[0][i-1])/1000000.0) : 0 ;
		double theta=exp(-2*dist);

                for (j = 0; j <= hmm->N-1; j++) {
                        sumlogprob = LZERO;
                        for (k = 0; k <= hmm->N-1; k++) {
				double transprob;
				if(TPupdate == 1) {
					transprob=(j==k)?(1-hmm->tran[k]):hmm->tran[k]/(hmm->N-1);
				}
				else{
					transprob=(j==k)?theta:(1-theta)/(hmm->N-1);
				}
				transprob=MAX(f_TransProb,transprob);   //floor transition prob
				
				logprob = alpha[i-1][k] + log(transprob); 
                                sumlogprob = LAdd(sumlogprob, logprob);
			}
                        alpha[i][j] = sumlogprob + hmm->Er[j][i-1] + hmm->Ez[j][i-1];
			//alpha[i][j] = sumlogprob + hmm->E[j][i];
                }
        }

 	 
        /* backward */
	
	for (i = 0; i <= hmm->N-1; i++)
                beta[hmm->M][i] = log(1.0 / hmm->N);

 	for (i = hmm->M - 1; i >= 0; i--) {

		float dist = (i == (hmm->M-1)) ? 0: ((hmm->data[0][i+1]- hmm->data[0][i])/1000000.0);
		double theta=exp(-2*dist);

                for (j = 0; j <= hmm->N-1; j++) {
                        sumlogprob = LZERO;
                        for (k = 0; k <= hmm->N-1; k++) {
				double transprob;
				if(TPupdate  == 1) {
					transprob=(j==k)?(1-hmm->tran[j]):hmm->tran[j]/(hmm->N-1);
				}
				else{
					transprob=(j==k)?theta:(1-theta)/(hmm->N-1);
				}
				transprob=MAX(f_TransProb,transprob);   //floor transition prob
	
                                logprob = beta[i+1][k] + log(transprob) + hmm->Er[k][i] + hmm->Ez[k][i];
				sumlogprob = LAdd(sumlogprob, logprob); 
			}
                        beta[i][j] = sumlogprob;
                }
        }

	/* caculat log score */
	*pprob = 0.0;
        for (i = 0; i <= hmm->N-1; i++)
                *pprob  = LAdd(LZERO, alpha[hmm->M][i]);
	
}

void ForwardBackwardUpdate(HMM *hmm, double **alpha, double **beta, int GCcorrection, int TPupdate) {
	/*update parm*/
	
	int i, j, k, t;
	double *nsample= dvector(hmm->N);
	double **mean = dmatrix(hmm->N,2);
	double **var = dmatrix(hmm->N,2);	

	double **gamma = dmatrix(hmm->M,hmm->N);
	double **eta_ij = dmatrix(hmm->N,hmm->N);
	double eta_i[hmm->N];
	 

	if(TPupdate == 1) {
		for(i=0; i<=hmm->N-1 ; i++){
			for(j=0; j<=hmm->N-1 ; j++){
				eta_ij[i][j]=LZERO;
			}
			eta_i[i]=LZERO;
		}
	}
	 
	for(t=1;t<=hmm->M; t++){
		double LogProbSum = LZERO;
		for(i=0; i<=hmm->N-1 ; i++){
     			 gamma[t-1][i] = alpha[t][i]+beta[t][i];
     			 LogProbSum = LAdd(LogProbSum,gamma[t-1][i]);

			if( TPupdate == 1 && t < hmm->M) {
;
     			 	for(j=0; j<=hmm->N-1 ; j++){ 
					double transprob=(j==i)?(1-hmm->tran[i]):hmm->tran[i]/(hmm->N-1);
					transprob= MAX(f_TransProb,transprob);   //floor transition prob
					eta_ij[i][j] = LAdd(eta_ij[i][j], (alpha[t][i] + log(transprob) + hmm->Er[j][t]  + hmm->Ez[j][t] + beta[t+1][j]));
     			 	}
     				eta_i[i] = LAdd(eta_i[i],gamma[t-1][i]);
			}
    		}
		for(i=0; i<=hmm->N-1 ; i++){
			gamma[t-1][i]=exp(gamma[t-1][i] - LogProbSum);
			for(k=0; k<=1; k++) {
				mean[i][k] += hmm->data[1+k][t-1]  * gamma[t-1][i];
			} 
      			nsample[i] += gamma[t-1][i];
		}
		
 	 }

	/*update mean*/
	for (j = 0; j <= hmm->N-1; j++) {
		for(k=0;k<=1;k++) {
			hmm->mean[j][k]= mean[j][k] / nsample[j];
		}
	}

	for(t=1;t<=hmm->M; t++){
		for(i=0; i<=hmm->N-1 ; i++){
			for(k=0; k<=1; k++){
				var[i][k] += gamma[t-1][i] * pow(hmm->data[k+1][t-1] -mean[i][k],2) ;
			}
		}
	}
	/*update var*/
	for (j = 0; j <= hmm->N-1; j++) {
		for(k=0;k<=1;k++) {
			hmm->var[j][k] = var[j][k]/(nsample[j]-1);
		}
	}

	/*update transP*/
	if( TPupdate  == 1){
		for(i=0; i<=hmm->N-1 ; i++){
			double Sum = 0.0;
			double transSum = 0.0;
			for(j=0; j<=hmm->N-1 ; j++){
				double prob=exp(eta_ij[i][j]-eta_i[i]);
				Sum += prob;
				if(i == j) continue;
				transSum += prob;
			}
			hmm->tran[i] = transSum/ Sum;
			if(hmm->tran[j]<f_TransProb) hmm->tran[j] = f_TransProb;
  		}
	}

	free_dvector(nsample,hmm->N);
	free_dmatrix(mean,hmm->N,2);
	free_dmatrix(var,hmm->N,2);
	free_dmatrix(gamma,hmm->M,hmm->N);
	free_dmatrix(eta_ij,hmm->N,hmm->N);

	UpdateEmissHMM(hmm);
}
