/***************************************************************************
 *   Copyright (C) 2008 by Xiaoqi Shi   *
 *   xshi@linus223   *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/


#include "nrutil.h"
#include "hmm.h"
#ifndef VERSION
#define VERSION "test"
#endif

extern char *optarg;
extern int optind, optopt; 

int main (int argc, char **argv)
{
	 
	if (argc < 2) return usage();
	if (strcmp(argv[1], "cnsdepth") == 0)  {
		h_DepthCNS(argc-1, argv+1);
		return 1;
	}
	else if (strcmp(argv[1], "hmm") == 0) {
		h_HMM(argc-1, argv+1);
		return 1;
	}
	else if (strcmp(argv[1], "cmds") == 0) {
		h_CMDS(argc-1, argv+1);
		return 1;
	}
	else {
		fprintf(stderr, "ERROR: unrecognized command '%s'\n", argv[1]);
		return 2;
	}
	 
 	
}
int usage(char *name)
{
	fprintf(stderr, "\n");
	fprintf(stderr, "Program: cnv (copy number analysis using hidden markov algorithm and cmds)\n");
	fprintf(stderr, "Version: %s\n", VERSION);
	fprintf(stderr, "Author: Xiaoqi Shi, Ken Chen & Qunyuan\n\n");
	fprintf(stderr, "Usage:   cnv <command> [options]\n\n");
	fprintf(stderr, "Key commands:\n");
	fprintf(stderr, "	cnsdepth	create depth file\n");
	fprintf(stderr, "	hmm             run HMM analysis\n");
	fprintf(stderr, "	cmds            run CMDS analysis\n");
	fprintf(stderr, "	sv              run structure variation analysis\n");
	fprintf(stderr, "\n\n");
	return 1; 
}
