
#include "nrutil.h"
#include "hmm.h"
#ifndef VERSION
#define VERSION "1.0"
#endif

extern char *optarg;
extern int optind, optopt; 

int main (int argc, char **argv)
{
	 
	if (argc < 2) return usage();
	if (strcmp(argv[1], "cnsdepth") == 0)  {
		h_DepthCNS(argc-1, argv+1);
		return 1;
	}
	else if (strcmp(argv[1], "hmm") == 0) {
		h_HMM(argc-1, argv+1);
		return 1;
	}
	else if (strcmp(argv[1], "cmds") == 0) {
		h_CMDS(argc-1, argv+1);
		return 1;
	}
	else {
		fprintf(stderr, "ERROR: unrecognized command '%s'\n", argv[1]);
		return 2;
	}
	 
 	
}
int usage(char *name)
{
	fprintf(stderr, "\n");
	fprintf(stderr, "Program: cnv (copy number analysis using hidden markov algorithm and cmds)\n");
	fprintf(stderr, "Version: %s\n", VERSION);
	fprintf(stderr, "Author: Xiaoqi Shi, Ken Chen & Qunyuan\n\n");
	fprintf(stderr, "Usage:   cnv <command> [options]\n\n");
	fprintf(stderr, "Key commands:\n");
	fprintf(stderr, "	cnsdepth	create depth file\n");
	fprintf(stderr, "	hmm             run HMM analysis\n");
	fprintf(stderr, "	cmds            run CMDS analysis\n");
	fprintf(stderr, "\n\n");
	return 1; 
}
