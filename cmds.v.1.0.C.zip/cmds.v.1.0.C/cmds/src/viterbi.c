/***************************************************************************
 *   Copyright (C) 2008 by Xiaoqi Shi   *
 *   xshi@linus223   *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#include "hmm.h"
#include "nrutil.h"


 

void Viterbi(HMM *hmm, int *state, double *val, int TPupdate)
{
        int     i, j;
        int     t;
 	 
        double	logprob, maxlogprob;
        double	maxstate;
	  
	double	**delta=dmatrix(hmm->M,hmm->N); 
// 	double	delta[hmm->M][hmm->N];
	int	**phi=imatrix(hmm->M,hmm->N);

        for (i = 0; i <= hmm->N-1; i++) {
                delta[0][i] = hmm->Er[i][0]+hmm->Ez[i][0];
                phi[0][i] = -999;
        }

        for (t = 1; t <= hmm->M-1; t++) {

		float dist = (hmm->data[0][t]- hmm->data[0][t-1])/1000000.0 ;
		dist = (dist<0)? 10:dist;	//Assuming 10Mb distant in between if abnormal
		double theta=exp(-2*dist);

                for (j = 0; j <= hmm->N-1; j++) {
                        maxlogprob = LZERO;
                        maxstate = 0;
                        for (i = 0; i <= hmm->N-1; i++) { /*previous time point */
				//transition probability
				double transprob;
				if( TPupdate == 1) {
					transprob=(j==i)?(1-hmm->tran[i]):hmm->tran[i]/(hmm->N-1);
				}
				else{
					transprob=(j==i)?theta:(1-theta)/(hmm->N-1);
				}

				
                                logprob = delta[t-1][i] + log(transprob);
                                if (logprob > maxlogprob) {
                                        maxlogprob = logprob;
                                        maxstate = i;
                                }
                        }
 
                        delta[t][j] = maxlogprob + hmm->Er[j][t] + hmm->Ez[j][t]; 
                        phi[t][j] = maxstate;
 
                }
        }

        *val = LZERO;
        state[hmm->M-1] = 0;
        for (i = 0; i <= hmm->N-1; i++) {
                if (delta[hmm->M-1][i] > *val) {
                        *val = delta[hmm->M-1][i];
                        state[hmm->M-1] = i;
                }
        }
 
	for (t = hmm->M-2; t >= 0; t--)
		state[t] = phi[t+1][state[t+1]];

	free_dmatrix(delta,hmm->M,hmm->N);
	free_imatrix(phi,hmm->M,hmm->N);

}	
  

  
void ViterbiUpdate(HMM *hmm, int *state, int TPupdate)
{
	int i,j,k,count;
	int **transN = imatrix(hmm->N,hmm->N);
	int *nsample= ivector(hmm->N);
	double **mean = dmatrix(hmm->N,4);
	double **var = dmatrix(hmm->N,2);	
	

	for (i = 0; i <= hmm->M-1; i++) {
		int pstate=state[i];
		if(i<=hmm->M-2) transN[pstate][state[i+1]]++;
		for(k=0;k<=1;k++) {
			mean[pstate][k] += hmm->data[k+1][i];
			mean[pstate][k+2] ++;
		}
	}
	 
	/*  update mean  */
	for (j = 0; j <= hmm->N-1; j++) {
		for(k=0;k<=1;k++) {
			hmm->mean[j][k]= mean[j][k] / mean[j][k+2];
		}
	}

	for (i=0; i <= hmm->M-1; i++) {
		int pstate = state[i];
		for(k=0;k<=1;k++) {
			var[pstate][k] += pow(hmm->data[k+1][i] -hmm->mean[pstate][k],2);
		}
	}

	/*  update var  */
	for (j = 0; j <= hmm->N-1; j++) {
		for(k=0;k<=1;k++) {
			hmm->var[j][k] = var[j][k]/(mean[j][k+2]-1);
		}
	}

	/*  update transition  */
	if( TPupdate  == 1) 
	{
		for (j =0; j <= hmm->N-1; j++) {
			count = 0;
			for (k =0; k <= hmm->N-1; k++) {
				count += transN[j][k];
			}
			if(count > 0)  
				hmm->tran[j] = (count - transN[j][j] + 0.0) / count;
		
			if(hmm->tran[j]<f_TransProb) hmm->tran[j] = f_TransProb;
		}
	}
	 

	UpdateEmissHMM(hmm);
	free_imatrix(transN,hmm->N,hmm->N);
	free_ivector(nsample,hmm->N);
	free_dmatrix(mean,hmm->N,2); 
	free_dmatrix(var,hmm->N,2); 
} 